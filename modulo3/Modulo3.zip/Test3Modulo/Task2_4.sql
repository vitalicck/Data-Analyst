----------Task 2: Implementazione fisicamente del database e delle tabelle--------------------------------

CREATE DATABASE Modulo3;
USE Modulo3;


CREATE TABLE Category 
(
CategoryID INT PRIMARY KEY,
CategoryName VARCHAR(15)
);


CREATE TABLE Product
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(15),
CategoryID INT,
Quantity INT,
StandartCost DECIMAL(5,2),
FinishedGood BIT,
CONSTRAINT FK_CategoryID_P FOREIGN KEY (CategoryID) REFERENCES Category (CategoryID)
);


CREATE TABLE Sales
(
SalesID INT PRIMARY KEY,
ProductID INT,
StateID INT,
SalesLine INT,
SalesDate DATE,
OrderQuantity INT,
UnitPrice DECIMAL(5,2),
SalesAmount DECIMAL(5,2),
CONSTRAINT FK_ProductID_S FOREIGN KEY (ProductID) REFERENCES Product (ProductID)
);


CREATE TABLE Geography 
(
StateID INT PRIMARY KEY,
StateName VARCHAR(15),
RegionName VARCHAR(15)
);


ALTER TABLE Sales
ADD CONSTRAINT FK_StateID_S
FOREIGN KEY (StateID) REFERENCES Geography(StateID);

----------Task 3: Inserimento dei record per tabella--------------------------

INSERT INTO Category(CategoryID, CategoryName) VALUES 
(1, 'Toys'), (2, 'Games'), (3, 'Accessories');

INSERT INTO Product(ProductID, ProductName, CategoryID, Quantity, StandartCost, FinishedGood) VALUES 
(101, 'PigRobot', 1, 5, 30.00, 1), 
(102, 'Chess', 2, 8, 20.00, 1),
(103, 'TeddyBear', 1, 0, 15.00, 0),
(104, 'Suitcase', 3, 7, 7.00, 1),
(105, 'Monopoly', 2, 10, 10.00, 1);

INSERT INTO Sales(SalesID, ProductID, StateID, SalesLine, SalesDate, OrderQuantity, UnitPrice, SalesAmount) VALUES 
(1001, 102, 1, 1, '2024-01-28', 3, 25.00, 75.00), 
(1002, 104, 4, 1, '2023-08-24', 4, 10.00, 40.00),
(1003, 105, 2, 1, '2024-01-05', 3, 15.00, 45.00),
(1004, 101, 3, 1, '2023-12-22', 5, 35.00, 175.00),
(1005, 105, 2, 2, '2024-01-16', 2, 15.00, 30.00);


INSERT INTO Geography(StateID, StateName, RegionName) VALUES 
(1, 'UK', 'Europe'), (2, 'Italy', 'Europe'), (3, 'Japan', 'Asia'), (4, 'Canada', 'NorthAmerica');


----------Task 4------------------------------------------------

--1) Verificare che i campi definiti come PK sono univoci
SELECT CategoryID, COUNT(*) AS NUM
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) >1;

SELECT ProductID, COUNT(*) AS NUM
FROM Product
GROUP BY ProductID
HAVING COUNT(*) >0;

SELECT SalesID, COUNT(*) AS NUM
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) >1;

SELECT StateID, COUNT(*) AS NUM
FROM Geography
GROUP BY StateID
HAVING COUNT(*) >0;

/*2) Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto,
la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
in base alla condizione che siano passati piu' di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT SalesID 
,SalesDate
,p.ProductName 
,c.CategoryName
,g.StateName
,g.RegionName
,CASE WHEN DATEDIFF(DAY, SalesDate, GETDATE()) > 180 THEN 1 ELSE 0 END AS IsMoreThan180Days
FROM Sales AS s
INNER JOIN Product AS p
ON s.ProductID = p.ProductID
INNER JOIN Category AS c
ON p.CategoryID = c.CategoryID
INNER JOIN Geography AS g
ON s.StateID = g.StateID;

/*3) Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/

SELECT p.ProductName,  SUM(SalesAmount) AS TOTAL
FROM Product AS p
INNER JOIN Sales AS s
ON p.ProductID = s.ProductID
GROUP BY p.ProductName ;

/*4) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/

SELECT StateID, YEAR(SalesDate) AS ANNO, SUM(SalesAmount) AS TOTAL 
FROM Sales
GROUP BY StateID, YEAR(SalesDate)
ORDER BY YEAR(SalesDate), TOTAL DESC;

/*5) Rispondere alla seguente domanda: qual e' la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT TOP 1 c.CategoryID, c.CategoryName, COUNT(c.CategoryName) AS NUMCOUNT
FROM Sales AS s
INNER JOIN Product AS p
ON s.ProductID = p.ProductID
INNER JOIN Category AS c
ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryName, c.CategoryID
ORDER BY NUMCOUNT DESC;

/*6) Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

SELECT p.ProductID, p.ProductName
FROM Product AS p
LEFT JOIN Sales AS s 
ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

-------------altro  modo---------------
SELECT ProductID, ProductName
FROM Product
WHERE ProductID NOT IN (SELECT DISTINCT ProductID FROM Sales);

/*7) Esporre l�elenco dei prodotti cona la rispettiva ultima data di vendita (la data di vendita piu' recente)*/

SELECT p.ProductName, s.SalesDate
FROM Sales AS s
INNER JOIN Product AS p
ON s.ProductID = p.ProductID
ORDER BY s.SalesDate DESC;
----------------------------------------------
SELECT p.ProductName,
    (SELECT MAX(s.SalesDate) FROM Sales AS s WHERE s.ProductID = p.ProductID) AS LastSalesDate
FROM Product AS p;

/*8) Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)*/

CREATE VIEW ProductInfoView AS 
SELECT p.ProductID, p.ProductName, c.CategoryName
FROM Product AS p
INNER JOIN Category AS c
ON p.CategoryID = c.CategoryID;

/* 9) Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche*/

CREATE VIEW GeographyInfoView AS
SELECT *
FROM Geography

